export class logModel{
    constructor(
        public email:String,
        public password:String
    ){}
}