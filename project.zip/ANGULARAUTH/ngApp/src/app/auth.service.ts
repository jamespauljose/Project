import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _registerUrl = "http://localhost:3000/api/register";
  private _loginUrl = "http://localhost:3000/api/login";
  private _profileUrl = "http://localhost:3000/api/profile";


  constructor(private http: HttpClient,
    private _router: Router) { }

  registerUser(user) {
    return this.http.post<any>(this._registerUrl, user)
  }
  loginUser(user) {
    return this.http.post<any>(this._loginUrl, user)
  }
  profile(profile){
    return this.http.post<any>(this._profileUrl, profile)
  }

  loggedIn() {
    return !!localStorage.getItem('token')
  }
  logoutUser(){
   localStorage.removeItem('token')
   this._router.navigate(['/events'])

  }
  getToken() {
    return localStorage.getItem('token')
  }
}
