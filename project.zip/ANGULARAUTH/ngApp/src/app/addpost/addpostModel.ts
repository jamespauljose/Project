export class addpostModel{
    constructor(
        public postdata:String
    ){}
}