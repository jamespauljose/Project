const express = require('express');
const jwt = require('jsonwebtoken')
const router = express.Router()
const User = require('../models/user')
const Addpost = require('../models/addpost');
var cors = require('cors');


const mongoose = require('mongoose');

const db = "mongodb+srv://user_james:kokkandathil@mycluster.rt58q.azure.mongodb.net/eventsdb?retryWrites=true&w=majority"
 mongoose.connect(db, err => {
     if(err) {
         console.error('Error!' +err)
     } else{
         console.log('Connected to mongodb')
     }
 })
 function verifyToken(req,res, next){
   if (!req.headers.authorization){
     return res.status(401).send('Unauthorized Request')
   }
   let token = req.headers.authorization.split(' ')[1]
   if (token === 'null') {
    return res.status(401).send('Unauthorized request')
  }
   let payload = jwt.verify(token, 'secretKey')
   if(!payload) {
    return res.status(401).send('Unauthorized request')
   }
   req.userId = payload.subject
   next()

 }

router.get('/', (req, res) => {
    res.send('From API')

})
router.post('/register', (req, res) =>{
    let userData = req.body
    let user = new User(userData)
    user.save((error, registeredUser) => {
        if (error) {
            console.log(error)
        } else {
          let payload = { subject: registeredUser._id}
          let token = jwt.sign(payload, 'secretkey')
          res.status(200).send({token})
        }
    })
})
router.post('/login', (req, res) =>{
    let userData = req.body

    User.findOne({email: userData.email}, (error, user)=>{
        if (error) {
            console.log(error)
        } else {
            if (!user) {
                res.status(401).send('Invalid email')
                alert("invalid email or password")
            } else {
                if (user.password != userData.password) {
                    res.status(401).send('Invalid password')
                    alert("invalid password")
                } else {
                  let payload = { subject: user._id }
                  let token = jwt.sign(payload, 'secretkey')
                  res.status(200).send({token})
                }
            }
        }
    })
})

router.get('/events', (req, res) => {

    
})
router.get('/special', verifyToken,(req, res) => {
})
router.post('/addpost',(req,res)=>{
    let addp = req.body.addpost;
    var p = {
        postdata:addp.postdata
    }
    console.log(p)
    let addpost = new Addpost(p);
    addpost.save((err,data)=>{
        if(err){console.log(err)}
        else{
            res.status(200).send(data);
        }
    });

})
router.get('/postlist',(req,res)=>{
    let data = new postdata;
    postdata.find()
    .then((data)=>{
        console.log(data)
        res.send(data)
    })

})





module.exports = router