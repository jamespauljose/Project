const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const addpostSchema = new Schema({
    postdata:String
})
module.exports=mongoose.model('addpost',addpostSchema,'addpostdatas')