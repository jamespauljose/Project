import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { addpostModel } from '../addpost/addpostModel';
import { AddpostService } from '../addpost.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-addpost',
  templateUrl: './addpost.component.html',
  styleUrls: ['./addpost.component.css']
})
export class AddpostComponent implements OnInit {

  constructor(private router:Router,
    private addpostservice: AddpostService) { }
    addpost1= new addpostModel(null);


  ngOnInit(): void {
  }
  Addpost(){
    console.log(this.addpost1);
    this.addpostservice.newAddpost(this.addpost1)
    alert("success")
    this.router.navigate(['/special'])
  
  }

}
