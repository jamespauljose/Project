import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { addpostModel } from './addpost/addpostModel';

import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddpostService { private addpostmodel:addpostModel;


  constructor(private http:HttpClient) { }
  
  getpostlist(){
    return this.http.get("http://localhost:3000/api/postlist");
    

  }
  newAddpost(data){
    console.log("new addpost");
    console.log(data.postdata);
    return this.http.post("http://localhost:3000/api/addpost",{"addpost":data})
    .subscribe(data=>{console.log(data)})
  }
  deletepost(x){
    console.log("inside service")
    console.log(x)
    return this.http.post("http://localhost:3000/api/deletepost",{"data":x})
    .subscribe(data=>{console.log(data)})
  }
  editpost(x){
    return this.http.post("http://localhost:3000/api/editpost",{"addpost":x})
    .subscribe(data=>{console.log(data)})
  }
  setter(x){
    this.addpostmodel=x;

  }
  eg1(){return this.addpostmodel}

}
