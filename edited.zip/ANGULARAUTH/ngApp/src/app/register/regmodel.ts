export class regModel{
    constructor(
        public email:String,
        public name:String,
        public password:String

    ){}
}