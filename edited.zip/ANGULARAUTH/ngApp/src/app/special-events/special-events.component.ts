import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router'
import { addpostModel } from '../addpost/addpostModel'
import { AddpostService } from '../addpost.service';

import { from } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-special-events',
  templateUrl: './special-events.component.html',
  styleUrls: ['./special-events.component.css']
})
export class SpecialEventsComponent implements OnInit {
  
  specialEvents = []

  addp:addpostModel[];
  constructor(private _eventService: EventService,private addpostservice:AddpostService,
              private _router: Router) { }
  addpost(){
    this._router.navigate(['/addpost'])
  }
  editpost(data){
    this.addpostservice.setter(data)
    this._router.navigate(['/editpost'])
  }
  deletepost(data){
    this.addpostservice.deletepost(data)
    location.reload();
  }


  ngOnInit():void {
    this._eventService.getSpecialEvents()
      .subscribe((data)=>{this.specialEvents=JSON.parse(JSON.stringify(data))}
      )}
       
  show:boolean =true;
  showbtn(){
    this.show=!this.show;
  }


}
